Léane Texier

Question 11:
http://webtp.fil.univ-lille1.fr/~texierl/feuille5/question11.php

Question12:
http://webtp.fil.univ-lille1.fr/~texierl/feuille5/question12.html

Question13:
http://webtp.fil.univ-lille1.fr/~texierl/feuille5/question13.html
