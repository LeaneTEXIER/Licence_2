Léane Texier

Exercice 1:
cf answers.sql


Exercice 2:

Question1:
http://webtp.fil.univ-lille1.fr/~texierl/feuille8/formulaireAdresses.php?cCommune=59009
http://webtp.fil.univ-lille1.fr/~texierl/feuille8/formulaireAdresses.php?cCommune=59350

Question2-3 (Exemples):
http://webtp.fil.univ-lille1.fr/~texierl/feuille8/reponseAdresses.php?cVoie=2020&cCommune=59009
http://webtp.fil.univ-lille1.fr/~texierl/feuille8/reponseAdresses.php?cVoie=0084&cCommune=59350
