=============
Compact Trie
=============


.. automodule:: compacttrie
   :members: 
