================================================================
Une structure de données arborescente pour stocker des mots
================================================================


--------------------------------------------------
TP6: Léane TEXIER & Antonio Viana SIMONE JUNIOR
--------------------------------------------------

.. toctree::
   :maxdepth: 1

   answers
   trie
   compacttrie




